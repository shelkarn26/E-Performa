package com.example.student_performance_monitoring_app

import io.flutter.embedding.android.FlutterActivity


class MainActivity: FlutterActivity() {
    
}
