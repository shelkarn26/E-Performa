import 'package:flutter/material.dart';

class AllottedStudentsToTeacher extends StatelessWidget {
  const AllottedStudentsToTeacher({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
